#!/bin/bash

read -p "Enter your DuckDNS sub-domain: " DOMAIN

# Strip duckdns.org, in case the user entered that
DOMAIN=${DOMAIN%.duckdns.org}
if [[ "$DOMAIN" == *.* ]]
then
  echo "Sub-domain must not contain any '.' characters - please try again"
  exit 1
fi

read -p "Enter your account token: " TOKEN
# Strip spaces and check format
TOKEN=$(echo $TOKEN)
if [[ "$TOKEN" != *-*-*-*-* ]]
then
  echo "Invalid token format - please try again"
  exit 1
fi

echo "Performing initial update"
UPDATE_URL="https://www.duckdns.org/update?domains=${DOMAIN}&token=${TOKEN}&ip=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)"

RESULT=$(curl -s "$UPDATE_URL")
if [[ "$RESULT" != "OK" ]]
then
  echo "Error updating DNS entry ($RESULT) - please check your domain and token values and try again"
  exit 1
fi

echo "Adding crontab entry to refresh DNS"
crontab -l > /tmp/duckdns.crontab 2> /dev/null
echo "*/5 * * * * curl -s \"https://www.duckdns.org/update?domains=${DOMAIN}&token=${TOKEN}&ip=\$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)\" > /dev/null 2>&1" >> /tmp/duckdns.crontab
crontab /tmp/duckdns.crontab
rm -f /tmp/duckdns.crontab

echo "Done."