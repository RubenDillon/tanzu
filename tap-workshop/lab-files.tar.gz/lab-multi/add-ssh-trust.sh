#!/bin/bash -e

if [[ -z "$1" ]]
then
  echo "Usage: $0 host"
  exit 1
fi

HOST="$1"

# Set up local SSH directory

SSH_DIR=$HOME/.ssh
mkdir -p -m 0700 $SSH_DIR

# Create a key if not already present

if [[ ! -f $SSH_DIR/id_ecdsa ]]
then
  ssh-keygen -t ecdsa -q -f $SSH_DIR/id_ecdsa -N ""
fi

# Add trust relationship

cat $SSH_DIR/id_ecdsa.pub | \
  sshpass -pH3pt10 ssh -oStrictHostKeyChecking=no ubuntu@$HOST 'mkdir -p -m 0700 ${HOME}/.ssh && \
    cat >> $HOME/.ssh/authorized_keys && \
    chmod 0600 $HOME/.ssh/authorized_keys'

# Test it!

ssh $HOST echo "Trust relationship to $HOST successfully set up." || echo "ERROR: Remote execution failed"
