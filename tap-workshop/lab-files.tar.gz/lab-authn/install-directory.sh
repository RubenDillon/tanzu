#!/bin/bash -e

CERTIFICATES=/home/automation/certificates
ROOT_USER_DN='cn=Directory Manager'
ROOT_PASSWORD='opendjpassword'
WORKDIR=$HOME/directory
OPENDJ_DIR=$WORKDIR/opendj
DEX_DIR=$WORKDIR/dex
LDAP_URL=ldaps://ldap.master.tap.lab:30636

function log() {
  echo "====="
  echo $*
  echo "====="
}

log "Installing LDAP tools"

sudo apt install -y ldap-utils

log "Setting up server configuration"

mkdir -p $OPENDJ_DIR

# Make key file readable

sudo chmod a+r $CERTIFICATES/host-0.*

# Create PKCS12 format version of certificate

openssl pkcs12 -export -out $OPENDJ_DIR/host.pfx \
  -inkey $CERTIFICATES/host-0.key -in $CERTIFICATES/host-0.crt \
  -certfile $CERTIFICATES/TAP-CA.crt -passout pass:"$ROOT_PASSWORD"

cat <<EOF > $OPENDJ_DIR/secret.yaml
apiVersion: v1
data:
  host.pfx: $(base64 -w 0 $OPENDJ_DIR/host.pfx)
kind: Secret
metadata:
  name: opendj-certs
type: Opaque
EOF

cat <<EOF > $OPENDJ_DIR/opendj.yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: opendj
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: opendj
spec:
  replicas: 1
  selector:
    matchLabels:
      app: opendj
  template:
    metadata:
      labels:
        app: opendj
    spec:
      containers:
      - name: opendj
        image: openidentityplatform/opendj:4.5.4
        env:
        - name: BASE_DN
          value: "dc=tanzu,dc=academy"
        - name: ROOT_USER_DN
          value: "$ROOT_USER_DN"
        - name: ROOT_PASSWORD
          value: "$ROOT_PASSWORD"
        - name: OPENDJ_SSL_OPTIONS
          value: "--usePkcs12KeyStore /certs/host.pfx --keyStorePassword $ROOT_PASSWORD"
        volumeMounts:
        - name: certs
          mountPath: /certs
        - name: data
          mountPath: /opt/opendj/data
      volumes:
      - name: certs
        secret:
          secretName: opendj-certs
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: [ ReadWriteOnce ]
      storageClassName: local-path
      resources:
        requests:
          storage: 1Gi
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app: opendj
  name: opendj
spec:
  ports:
  - nodePort: 30636
    port: 1636
    protocol: TCP
    targetPort: 1636
  selector:
    app: opendj
  type: NodePort
---
EOF

log "Deploying directory server"

kapp deploy -y -a opendj --into-ns opendj -f $OPENDJ_DIR

log "Waiting for directory server to be ready ..."

while ! ldapsearch -H $LDAP_URL -D "$ROOT_USER_DN" -w "$ROOT_PASSWORD" '(cn=*)' > /dev/null 2>&1
do
  echo "Sleeping for 5 seconds"
  sleep 5
done

log "Loading users and groups (errors can be ignored if already loaded)"

cat > $WORKDIR/data.ldif << 'EOF'
dn: ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: organizationalUnit
ou: users
description: Users

dn: uid=ada,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Ada Lovelace
sn: Lovelace
mail: ada.lovelace@analytical.eng
uid: ada
userPassword: Secret!
description: Augusta Ada King, Countess of Lovelace was an English
  mathematician and writer, chiefly known for her work on Charles
  Babbage's proposed mechanical general-purpose computer, the Analytical
  Engine.

dn: uid=charles,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Charles Babbage
sn: Babbage
mail: charles.babbage@analytical.eng
uid: charles
userPassword: Secret!
description: Charles Babbage KH FRS was an English polymath. A
  mathematician, philosopher, inventor and mechanical engineer, Babbage
  originated the concept of a digital programmable computer. Babbage is
  considered by some to be "father of the computer".

dn: uid=dorothy,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Dorothy Vaughan
sn: Vaughan
mail: dorothy.vaughan@nasa.gov
uid: dorothy
userPassword: Secret!
description: Dorothy Jean Johnson Vaughan was an American mathematician
  and human computer who worked for the National Advisory Committee for
  Aeronautics, and NASA, at Langley Research Center in Hampton, Virginia.

dn: uid=mary,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Mary Jackson
sn: Jackson
mail: mary.jackson@nasa.gov
uid: mary
userPassword: Secret!
description: Mary Jackson was an American mathematician and aerospace
  engineer at the National Advisory Committee for Aeronautics, which in
  1958 was succeeded by the National Aeronautics and Space Administration.
  She worked at Langley Research Center in Hampton, Virginia, for most
  of her career.

dn: uid=grace,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Grace Hopper
sn: Hopper
mail: grace.hopper@navy.mil
uid: grace
userPassword: Secret!
description: Grace Brewster Hopper was an American computer scientist,
  mathematician, and United States Navy rear admiral. One of the first
  programmers of the Harvard Mark I computer, she was a pioneer of
  computer programming who invented one of the first linkers.

dn: uid=john,ou=users,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: John von Neumann
sn: von Neumann
mail: john.von.neumann@ams.org
uid: john
userPassword: Secret!
description: John von Neumann was a Hungarian-American mathematician,
  physicist, computer scientist, engineer and polymath.

dn: ou=groups,dc=tanzu,dc=academy
objectClass: top
objectClass: organizationalUnit
ou: groups
description: Groups

dn: cn=developers,ou=groups,dc=tanzu,dc=academy
objectClass: top
objectClass: groupOfNames
cn: developers
member: uid=ada,ou=users,dc=tanzu,dc=academy
member: uid=dorothy,ou=users,dc=tanzu,dc=academy
member: uid=grace,ou=users,dc=tanzu,dc=academy

dn: cn=engineers,ou=groups,dc=tanzu,dc=academy
objectClass: top
objectClass: groupOfNames
cn: engineers
member: uid=charles,ou=users,dc=tanzu,dc=academy
member: uid=mary,ou=users,dc=tanzu,dc=academy
member: uid=grace,ou=users,dc=tanzu,dc=academy

dn: cn=testers,ou=groups,dc=tanzu,dc=academy
objectClass: top
objectClass: groupOfNames
cn: testers
member: uid=charles,ou=users,dc=tanzu,dc=academy
member: uid=grace,ou=users,dc=tanzu,dc=academy

dn: cn=admins,ou=groups,dc=tanzu,dc=academy
objectClass: top
objectClass: groupOfNames
cn: admins
member: uid=grace,ou=users,dc=tanzu,dc=academy
member: uid=john,ou=users,dc=tanzu,dc=academy

dn: ou=service-accounts,dc=tanzu,dc=academy
objectClass: top
objectClass: organizationalUnit
ou: service-accounts
description: Service Accounts

dn: uid=pinniped-supervisor,ou=service-accounts,dc=tanzu,dc=academy
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: Pinniped Supervisor process
sn: Functional Account
uid: pinniped-supervisor
userPassword: Super!Secret!
EOF

ldapadd -c -H $LDAP_URL -D "$ROOT_USER_DN" -w "$ROOT_PASSWORD" -f $WORKDIR/data.ldif || true

log "Deploying Dex OIDC server"

mkdir -p $DEX_DIR

export DEX_CA_DATA=$(base64 -w 0 $CERTIFICATES/TAP-CA.crt)
export DEX_KEY_DATA=$(base64 -w 0 $CERTIFICATES/host-0.key)
export DEX_CRT_DATA=$(base64 -w 0 $CERTIFICATES/host-0.crt)
export LDAP_CA_DATA="${DEX_CA_DATA}"

cat > $DEX_DIR/dex.yaml <<EOF 
---
apiVersion: v1
kind: Namespace
metadata:
  name: dex
---
apiVersion: v1
kind: Secret
metadata:
  name: dex-tls
  namespace: dex
type: kubernetes.io/tls
data:
  ca.crt: ${DEX_CA_DATA}
  tls.crt: ${DEX_CRT_DATA}
  tls.key: ${DEX_KEY_DATA}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: dex
  name: dex
  namespace: dex
spec:
  replicas: 3
  selector:
    matchLabels:
      app: dex
  template:
    metadata:
      labels:
        app: dex
    spec:
      serviceAccountName: dex # This is created below
      containers:
      - image: ghcr.io/dexidp/dex:v2.35.3
        name: dex
        command: ["/usr/local/bin/dex", "serve", "/etc/dex/cfg/config.yaml"]

        ports:
        - name: https
          containerPort: 5556

        volumeMounts:
        - name: config
          mountPath: /etc/dex/cfg
        - name: tls
          mountPath: /etc/dex/tls

        readinessProbe:
          httpGet:
            path: /healthz
            port: 5556
            scheme: HTTPS
      volumes:
      - name: config
        configMap:
          name: dex
          items:
          - key: config.yaml
            path: config.yaml
      - name: tls
        secret:
          secretName: dex-tls
---
kind: ConfigMap
apiVersion: v1
metadata:
  name: dex
  namespace: dex
data:
  config.yaml: |
    issuer: https://dex.master.tap.lab
    storage:
      type: kubernetes
      config:
        inCluster: true
    web:
      https: 0.0.0.0:5556
      tlsCert: /etc/dex/tls/tls.crt
      tlsKey: /etc/dex/tls/tls.key

    oauth2:
      skipApprovalScreen: true
      passwordConnector: ldap

    connectors:
    - type: ldap
      name: OpenDJ
      id: ldap
      config:

        host: ldap.master.tap.lab:30636
        insecureNoSSL: false
        insecureSkipVerify: false
        rootCAData: ${LDAP_CA_DATA}

        # This would normally be a read-only user.
        bindDN: uid=pinniped-supervisor,ou=service-accounts,dc=tanzu,dc=academy
        bindPW: Super!Secret!

        usernamePrompt: User ID

        userSearch:
          baseDN: ou=users,dc=tanzu,dc=academy
          filter: "(objectClass=person)"
          username: uid
          # "DN" (case sensitive) is a special attribute name. It indicates that
          # this value should be taken from the entity's DN not an attribute on
          # the entity.
          idAttr: uid
          emailAttr: mail
          nameAttr: cn

        groupSearch:
          baseDN: ou=groups,dc=tanzu,dc=academy
          filter: "(objectClass=groupOfNames)"

          userMatchers:
            # A user is a member of a group when their DN matches
            # the value of a "member" attribute on the group entity.
          - userAttr: DN
            groupAttr: member

          # The group name should be the "cn" value.
          nameAttr: cn

    staticClients:
    - id: tap-gui
      redirectURIs:
      - 'https://tap-gui.master.tap.lab/api/auth/oidc/handler/frame'
      name: 'TAP GUI'
      secret: Very!Very!Secret!
  
    - id: pinniped-supervisor
      name: "Pinniped Supervisor"
      secret: Even!More!Secret!
      redirectURIs:
      - 'https://pinniped-supervisor.master.tap.lab/callback'

    - id: gitlab
      name: "GitLab"
      secret: Unbelievably!Secret!
      redirectURIs:
      - 'https://gitlab.master.tap.lab/users/auth/openid_connect/callback'

---
apiVersion: v1
kind: Service
metadata:
  name: dex
  namespace: dex
spec:
  type: ClusterIP
  ports:
  - name: dex
    port: 5556
    protocol: TCP
    targetPort: 5556
  selector:
    app: dex
---
apiVersion: projectcontour.io/v1
kind: HTTPProxy
metadata:
  name: dex
  namespace: dex
spec:
  virtualhost:
    fqdn: dex.master.tap.lab
    tls:
      passthrough: true
  tcpproxy:
    services:
    - name: dex
      port: 5556
---
apiVersion: v1
kind: ServiceAccount
metadata:
  labels:
    app: dex
  name: dex
  namespace: dex
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: dex
rules:
- apiGroups: ["dex.coreos.com"] # API group created by dex
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["apiextensions.k8s.io"]
  resources: ["customresourcedefinitions"]
  verbs: ["create"] # To manage its own resources, dex must be able to create customresourcedefinitions
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: dex
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: dex
subjects:
- kind: ServiceAccount
  name: dex           # Service account assigned to the dex pod, created above
  namespace: dex  # The namespace dex is running in
EOF

kapp deploy -y -a dex -f $DEX_DIR/dex.yaml

log "Done."