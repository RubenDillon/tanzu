#!/bin/bash -e

CERTIFICATES=/home/automation/certificates
GITLAB_DIR=$HOME/gitlab

function log() {
  echo "====="
  echo $*
  echo "====="
}

# Load Postgres credentials

source /home/automation/passwords.env

log "Setting up local GitLab instance"

mkdir -p $GITLAB_DIR

sudo chmod a+r $CERTIFICATES/host-0.*

export ROOT_CA_DATA=$(perl -pe 'chomp; s/$/\\n/' < $CERTIFICATES/TAP-CA.crt)
export HOST_0_CRT_DATA=$(perl -pe 'chomp; s/$/\\n/' < $CERTIFICATES/host-0.crt)
export HOST_0_KEY_DATA=$(perl -pe 'chomp; s/$/\\n/' < $CERTIFICATES/host-0.key)

cat > $GITLAB_DIR/gitlab.yaml <<EOF
apiVersion: v1
kind: Namespace
metadata:
  name: gitlab
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: gitlab-data
  namespace: gitlab
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: local-path
  resources:
    requests:
      storage: 10Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: gitlab-etc
  namespace: gitlab
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: local-path
  resources:
    requests:
      storage: 10Mi
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: trusted-certs
  namespace: gitlab
data:
  TAP-CA.crt: "${ROOT_CA_DATA}"
  host-0.crt: "${HOST_0_CRT_DATA}"
  host-0.key: "${HOST_0_KEY_DATA}"
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: gitlab
  namespace: gitlab
spec:
  replicas: 1
  selector:
    matchLabels:
      app: gitlab
  template:
    metadata:
      labels:
        app: gitlab
    spec:
      initContainers:
      - name: config-copier
        image: busybox:1.34.1
        command: ['sh', '-c', 'cp /mnt/configmap/*  /mnt/trusted-certs']
        volumeMounts:
        - name: trusted-certs-configmap
          mountPath: /mnt/configmap
        - name: trusted-certs
          mountPath: /mnt/trusted-certs        
      containers:
      - name: gitlab
        image: gitlab/gitlab-ce:15.9.3-ce.0
        ports:
        - name: http
          containerPort: 443
        - name: ssh
          containerPort: 22
        env:
        - name: GITLAB_OMNIBUS_CONFIG
          value: |
            external_url 'https://gitlab.master.tap.lab'
            letsencrypt['enable'] = false
            nginx['ssl_certificate'] = "/etc/gitlab/trusted-certs/host-0.crt"
            nginx['ssl_certificate_key'] = "/etc/gitlab/trusted-certs/host-0.key"
            nginx['custom_gitlab_server_config'] = "listen 80;"

            # Disable the bundled Redis
            redis['enable'] = false
            gitlab_rails['redis_host'] = 'harbor.tap.lab'
            gitlab_rails['redis_port'] = 6379

            # Disable the built-in Postgres
            postgresql['enable'] = false
            gitlab_rails['db_adapter'] = 'postgresql'
            gitlab_rails['db_encoding'] = 'utf8'
            gitlab_rails['db_host'] = 'harbor.tap.lab'
            gitlab_rails['db_port'] = 5432
            gitlab_rails['db_username'] = '${POSTGRES_USERNAME}'
            gitlab_rails['db_password'] = '${POSTGRES_PASSWORD}'

            gitlab_rails['initial_root_password'] = 'Top!Secret!'
            gitlab_rails['omniauth_allow_single_sign_on'] = ['openid_connect']
            gitlab_rails['omniauth_block_auto_created_users'] = false
            gitlab_rails['omniauth_providers'] = [
              {
                name: "openid_connect",
                label: "Dex", # optional label for login button, defaults to "Openid Connect"
                args: {
                  name: "openid_connect",
                  scope: ["openid","profile","email","groups"],
                  response_type: "code",
                  issuer: "https://dex.master.tap.lab",
                  discovery: true,
                  client_auth_method: "query",
                  send_scope_to_token_endpoint: "false",
                  pkce: true,
                  client_options: {
                    identifier: "gitlab",
                    secret: "Unbelievably!Secret!",
                    redirect_uri: "https://gitlab.master.tap.lab/users/auth/openid_connect/callback",
                    gitlab: {
                      groups_attribute: "groups",
                      admin_groups: ["admins"]
                    }
                  }
                }
              }
            ]
        volumeMounts:
        - name: gitlab-data
          mountPath: /var/opt/gitlab
        - name: gitlab-etc
          mountPath: /etc/gitlab
        - name: trusted-certs
          mountPath: /etc/gitlab/trusted-certs
      volumes:
      - name: gitlab-data
        persistentVolumeClaim:
          claimName: gitlab-data
      - name: gitlab-etc
        persistentVolumeClaim:
          claimName: gitlab-etc
      - name: trusted-certs-configmap
        configMap:
          name: trusted-certs
      - name: trusted-certs
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: gitlab
  namespace: gitlab
spec:
  ports:
  - name: https
    port: 443
    protocol: TCP
    targetPort: 443
  - name: http
    port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app: gitlab
---
apiVersion: v1
kind: Service
metadata:
  name: gitlab-ssh
  namespace: gitlab
spec:
  type: NodePort
  ports:
  - name: ssh
    port: 22
    protocol: TCP
    targetPort: 22
    nodePort: 32222
  selector:
    app: gitlab
---
apiVersion: projectcontour.io/v1
kind: HTTPProxy
metadata:
  name: gitlab-proxy
  namespace: gitlab
spec:
  virtualhost:
    fqdn: gitlab.master.tap.lab
    tls:
      passthrough: true
  routes:
  - conditions:
    - prefix: /
    services:
    - name: gitlab
      port: 80
    permitInsecure: true
  tcpproxy:
    services:
    - name: gitlab
      port: 443
EOF

kubectl apply -f $GITLAB_DIR/gitlab.yaml

log "Waiting for GitLab to become fully available (this will take several minutes)"

while [[ $(curl -sk -H "Content-Type:application/json" "https://gitlab.master.tap.lab/api/v4/projects/") != '[]' ]]
do
  echo "--- Sleeping for 15 seconds ---"
  sleep 15
  echo "... Latest log messages ..."
  kubectl logs -n gitlab deployment/gitlab -c gitlab | grep '^\[[0-9]' | tail -n 10
done

log "GitLab available -- pausing 10 seconds to allow it to stabilize"

sleep 10

log "Running post-install script"

# Personal access token must be be 20-40 chars. A UUID is 36.
# See: https://gitlab.com/gitlab-org/gitlab-foss/-/blob/master/app/models/personal_access_token.rb
TOKEN=$(uuidgen)

cat > $GITLAB_DIR/post-install.rb <<EOF
# This script configures some things which can't be configured
# via GITLAB_OMNIBUS_CONFIG and adds the 'workloads' user and
# token

# - Disable signup: https://gitlab.com/gitlab-org/omnibus-gitlab/-/issues/2837
ApplicationSetting.last.update(signup_enabled: false)

# - Disable auto-devops
ApplicationSetting.last.update(auto_devops_enabled: false)

# - Create user for workloads
user = User.new(username: 'workloads', email: 'workloads@gitlab.master.tap.lab', name: 'Workloads', password: 'Top!Secret!', password_confirmation: 'Top!Secret!')
user.skip_confirmation!
user.admin = true
user.save!

# - Create token
user = User.find_by_username('workloads')
token = user.personal_access_tokens.create(scopes: ['api', 'read_user', 'read_api', 'read_repository', 'write_repository'], name: 'Automation token')
token.set_token('$TOKEN')
token.save!
EOF

POD=$(kubectl get pod -n gitlab -o name | cut -d/ -f2)
# kubectl exec -it -n gitlab deployment/gitlab -- sh -c 'export DISABLE_DATABASE_ENVIRONMENT_CHECK=1; export force=yes; gitlab-rake gitlab:setup'
kubectl cp -n gitlab -c gitlab $GITLAB_DIR/post-install.rb $POD:/tmp
kubectl exec -it -n gitlab -c gitlab deployment/gitlab -- gitlab-rails runner /tmp/post-install.rb

log "Creating workloads/tap repository"

http POST https://gitlab.master.tap.lab/api/v4/projects/ \
  "PRIVATE-TOKEN:$TOKEN" \
  name=tap \
  description="TAP Workload Deliveries" \
  visbility=internal

git config --global user.name "Workloads"
git config --global user.email "workloads@gitlab.master.tap.lab"
git config --global http.sslCAInfo $CERTIFICATES/TAP-CA.crt

mkdir $GITLAB_DIR/tap
cd $GITLAB_DIR/tap
git init
cat > README.md << EOF
## TAP Workload Deliveries

This repository holds the configuration for deliveries generated
from TAP workloads.
EOF
git add .
git commit -m 'Initial commit'
git branch -m master main
git remote add origin "https://workloads:$TOKEN@gitlab.master.tap.lab/workloads/tap"
git push --set-upstream origin main

log "Creating application"

APP_INFO=$(http -b POST "https://gitlab.master.tap.lab/api/v4/applications" \
  "PRIVATE-TOKEN:$TOKEN" \
  name="TAP-GUI (pre-created)" \
  redirect_uri=https://tap-gui.master.tap.lab/api/auth/gitlab/handler/frame \
  scopes="api read_api read_user read_repository write_repository openid email"
)

APP_ID=$(echo "$APP_INFO" | jq -r '.application_id')
APP_SECRET=$(echo "$APP_INFO" | jq -r '.secret')

cat > $GITLAB_DIR/workloads.env <<EOF
export GITLAB_USERNAME='workloads'
export GITLAB_TOKEN='$TOKEN'
export GITLAB_CLIENT_ID='$APP_ID'
export GITLAB_CLIENT_SECRET='$APP_SECRET'
EOF

log "Uploading SSH key"

# Note - an SSH key has been generated in earlier labs for inter-machine
# communications, so we re-use that.
KEY=$(cat $HOME/.ssh/id_ecdsa.pub)

http POST https://gitlab.master.tap.lab/api/v4/user/keys \
  "PRIVATE-TOKEN:$TOKEN" \
  title=master \
  key="$KEY"

log "GitLab installation completed"